const category = 'toys' ; 

// console.log(`https://someurl.com/${category}/5`);
