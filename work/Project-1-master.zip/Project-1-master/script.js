"use strict";

// 

<h1>Hello World!</h1>
<h1>Hello World!</h1>
const user = "Ivan";

alert(`Привет, ${user}`);